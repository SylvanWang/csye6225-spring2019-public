# CSYE 6225 - Spring 2019

## Team Information

| Name | NEU ID | Email Address |
| Ranran He|001759737 |he.ra@husky.neu.edu |
| Sihan Zhao|001885132 |zhao.sih@husky.neu.edu |
| Mengqi Wang|001472783 |wang.mengqi2@husky.neu.edu |
| Yichuan Jiang| 001813365 | jiang.yic@husky.neu.edu |
## Technology Stack
Express Restful API Nodejs
restful Apt endpoints

## Build Instructions
npm install restful
build up server
build up databse with table: user
connect to mysql database
build up userController
write url for the resful endpoints in router: 
router.post('/user/register', user.createUser);
router.use('/', user.auth);
router.get('/', user.getTime);

## Deploy Instructions


## Running Tests


## CI/CD


