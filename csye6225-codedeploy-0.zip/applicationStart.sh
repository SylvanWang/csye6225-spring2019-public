#!/bin/bash
source /home/centos/.bash_profile
sudo systemctl start /etc/systemd/system/nodeserver && journalctl -fexu nodeserver.service >run.out 2>run.err &

