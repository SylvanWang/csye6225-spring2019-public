# csye6225-aws-cf-create-stack.sh is used to create resources: 
  it contians one parameter(VPCname) which should be entered in the consloe. 
  run by: sh "csye6225-aws-cf-create-stack.sh" VPCName
# csye6225-aws-cf-terminate-stack.sh is used to delete resources: 
  it contians one parameter(VPCname) which should be entered in the consloe
  run by: sh "csye6225-aws-cf-create-stack.sh" VPCName     
