# csye6225-aws-networking-setup.sh is used to create resources: 
  it contians one parameter(VPCname) which should be entered in the consloe. 
  run by: sh "csye6225-aws-networking-setup.sh" VPCName
# csye6225-aws-networking-teardown.sh is used to delete resources: 
  it contians one parameter(VPCname) which should be entered in the consloe
  run by: sh "csye6225-aws-networking-teardown.sh" VPCName
