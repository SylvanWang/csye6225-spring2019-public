
let noteModel = {

    id: String,
    content: String,
    title: String,
    createdOn: String,
    lastUpdatedOn: String,
    userId:String

}


module.exports = noteModel;